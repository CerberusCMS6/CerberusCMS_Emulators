#ifndef MZ_H
#define MZ_H

void LoadMzExeFromFile(char *filename);
void LoadCOMFromFile(char *filename);

void LoadMzExe(char *data, int size);
void LoadCOM(char *data, int size);

#endif //MZ_H
