/****************************************************************************
*                                                                           *
*                            Third Year Project                             *
*                                                                           *
*                            An IBM PC Emulator                             *
*                          For Unix and X Windows                           *
*                                                                           *
*                             By David Hedley                               *
*                                                                           *
*                                                                           *
* This program is Copyrighted.  Consult the file COPYRIGHT for more details *
*                                                                           *
****************************************************************************/


#ifndef DEBUGGER_H
#define DEBUGGER_H

unsigned disasm(unsigned seg, unsigned off, unsigned char *memory, char *buffer);

#endif

