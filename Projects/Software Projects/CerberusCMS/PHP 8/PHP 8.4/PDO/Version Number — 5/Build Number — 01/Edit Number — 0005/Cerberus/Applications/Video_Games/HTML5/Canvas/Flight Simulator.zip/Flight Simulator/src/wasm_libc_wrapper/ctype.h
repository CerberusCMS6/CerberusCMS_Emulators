#ifndef CTYPE_H
#define CTYPE_H

#ifndef __wasm__
	#include <ctype.h>
#else

int toupper(int c);

#endif

#endif
