#ifndef BIOS_H
#define BIOS_H

void HandleBios();

#endif
