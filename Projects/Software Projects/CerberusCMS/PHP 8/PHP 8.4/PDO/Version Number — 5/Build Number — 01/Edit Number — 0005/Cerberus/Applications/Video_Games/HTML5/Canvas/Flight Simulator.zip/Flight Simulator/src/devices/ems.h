#ifndef EMS_H
#define EMS_H

void EMSInterrupt();
void EMSInit();

#endif