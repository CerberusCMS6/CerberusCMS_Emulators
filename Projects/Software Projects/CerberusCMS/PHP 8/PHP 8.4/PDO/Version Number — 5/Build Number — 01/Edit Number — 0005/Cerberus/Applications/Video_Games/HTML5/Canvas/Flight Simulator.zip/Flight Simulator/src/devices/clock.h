#ifndef CLOCK_H
#define CLOCK_H

void Clock_Bios();

#endif
