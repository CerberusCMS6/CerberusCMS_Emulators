#ifndef MULTIPLEX_H
#define MULTIPLEX_H

void DOS_Multiplex_Int();

#endif
