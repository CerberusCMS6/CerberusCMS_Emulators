# Changelog

**Milligram** uses [GitHub's Releases feature](https://github.com/blog/1547-release-your-software) for its changelogs.

See our [releases](https://github.com/milligram/milligram/releases) to accompany at the improvements for each version of **Milligram**.
