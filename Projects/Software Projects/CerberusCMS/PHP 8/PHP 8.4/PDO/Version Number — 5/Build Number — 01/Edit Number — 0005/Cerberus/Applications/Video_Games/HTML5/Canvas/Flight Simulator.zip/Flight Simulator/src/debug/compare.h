#ifndef COMPARE_H
#define COMPARE_H

void compare(int _count);

#endif