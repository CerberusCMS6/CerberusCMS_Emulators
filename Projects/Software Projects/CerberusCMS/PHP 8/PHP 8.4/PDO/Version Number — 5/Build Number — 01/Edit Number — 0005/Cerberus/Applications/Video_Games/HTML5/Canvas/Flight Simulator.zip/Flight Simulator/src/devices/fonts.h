#ifndef FONTS_H
#define FONTS_H

#include "../wasm_libc_wrapper/stdint.h"

extern uint8_t int10_font_08[256 * 8];
extern uint8_t int10_font_14[256 * 14];
extern uint8_t int10_font_16[256 * 16];

#endif
