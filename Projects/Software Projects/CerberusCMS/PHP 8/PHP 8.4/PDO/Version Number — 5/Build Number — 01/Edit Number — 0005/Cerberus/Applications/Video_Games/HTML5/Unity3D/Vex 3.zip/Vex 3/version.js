version="tc-463";
libs=["./phaser-cachebuster.min.js","./phaser-spine.min.js","./phaser-super-storage.min.js","./phaser-i18next.min.js"];
