#ifndef DOS_H
#define DOS_H

void HandleDosInterrupt();
void DOSInit();

#endif
