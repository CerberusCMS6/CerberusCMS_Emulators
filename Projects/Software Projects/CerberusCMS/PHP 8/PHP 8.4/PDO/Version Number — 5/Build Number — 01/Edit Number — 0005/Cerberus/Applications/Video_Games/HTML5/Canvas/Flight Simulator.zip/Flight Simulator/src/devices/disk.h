#ifndef DISK_H
#define DISK_H

void Disk_Bios();
void RunImage(char* filename);

#endif
