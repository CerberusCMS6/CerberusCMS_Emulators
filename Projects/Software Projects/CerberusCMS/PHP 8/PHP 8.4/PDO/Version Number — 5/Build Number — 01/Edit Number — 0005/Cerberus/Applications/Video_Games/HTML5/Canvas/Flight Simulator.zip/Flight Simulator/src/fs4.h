#ifndef FS4_H
#define FS4_H

void FS4AlterFiles(const FILEFS *file, uint32_t addr, uint32_t size);
void FS4Expandexe();

#endif
