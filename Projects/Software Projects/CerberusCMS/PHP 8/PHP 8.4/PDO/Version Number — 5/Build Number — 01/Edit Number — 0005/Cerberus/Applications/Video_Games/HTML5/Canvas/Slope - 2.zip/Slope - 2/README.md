# Slope 2
![image](https://user-images.githubusercontent.com/81763982/162584270-725a5365-84c9-4645-be29-bb4ed786d812.png)

slope2
Slope 2 is a game from VSEIGRU, now on Github! Unofficial Second Installment of Slope!

[![Run on Repl.it](https://repl.it/badge/github/NYPDdev/Slope-2)](https://repl.it/github/NYPDdev/Slope-2)
