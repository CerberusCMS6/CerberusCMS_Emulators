# GopherCon Racing Game

Created by Jamilet Zelaya with very little help from Erick Zelaya.

# Run

You can simply double click on `index.html`.

Additionally you can also run with Docker (naturally it's required for this).
Apache will start and log all the requests.

```
make run
```

You can now go to http://localhost:8080 or use make.

```
make open
```

