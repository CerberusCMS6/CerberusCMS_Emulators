version="tc-188";
libs=["./phaser-cachebuster.min.js","./phaser-input.min.js","./phaser-nineslice.min.js","./phaser-spine.min.js","./phaser-super-storage.min.js"];
